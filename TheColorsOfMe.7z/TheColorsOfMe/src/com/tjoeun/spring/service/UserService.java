package com.tjoeun.spring.service;

import javax.annotation.Resource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Service;

import com.tjoeun.spring.beans.UserDTO;
import com.tjoeun.spring.dao.UserDAO;

@Service
public class UserService {
  
  @Autowired
  private UserDAO userDAO;
  
  @Resource(name="loginUserBean")
  @Lazy
  private UserDTO loginUserBean;
  
  public boolean checkUserId(String user_id) {
    String user_name = userDAO.checkUserId(user_id);  
    
    if(user_name == null) {
      return true;
    }else {
      return false;
    }
  }
  public void insertUserInfo(UserDTO userDTO) {
    userDAO.insertUserInfo(userDTO);
  }
  public void getLoginUserInfo(UserDTO initLoginUserBean) {
    
    UserDTO initLoginUserBean2 = userDAO.getLoginUserInfo(initLoginUserBean);
    
    // DB 에서 가져온 record의 컬럼값들을 
    // UserDTO의 setter 의 argument 로 넣어주어
    // UserDTO 의 멤버변수에 저장함
    if(initLoginUserBean2 != null) { // 아이디하고 비밀번호 일치 : 로그인 성공
      // Session 에 등록된 loginUserBean (UserDTO) 에 저장함
      loginUserBean.setUser_idx(initLoginUserBean2.getUser_idx());
      loginUserBean.setUser_name(initLoginUserBean2.getUser_name());
      loginUserBean.setLogLogin(true);
    }
  }
}
