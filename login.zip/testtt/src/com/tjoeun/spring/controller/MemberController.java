package com.tjoeun.spring.controller;

import javax.servlet.http.HttpSession;

import org.mybatis.logging.Logger;
import org.mybatis.logging.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.servlet.ModelAndView;

import com.tjoeun.spring.member.dto.MemberDTO;
import com.tjoeun.spring.member.service.MemberService;
import com.tjoeun.spring.member.service.MemberServiceImpl;

@Controller
@SessionAttributes("login")
public class MemberController {
	//private static final Logger logger = LoggerFactory.getLogger(MemberController.class);

	@Autowired
	private MemberService memberService;
	
	@RequestMapping("/login.do")
	public String login() {
		return "login";
	}

	@RequestMapping(value="/loginCheck.do")
	public ModelAndView login_check(@ModelAttribute MemberDTO dto,HttpSession session) {
		
	boolean result = memberService.loginCheck(dto, session);
		
		ModelAndView mav = new ModelAndView();
		
		mav.setViewName("login");
		
		if(result) {
			mav.addObject("msg","성공");
		}else {
		
			mav.addObject("msg","실패");
		}
		return mav;
		
	}
	
	@RequestMapping("logout.do") //logout.do에 매핑
  public ModelAndView logout(
          HttpSession session, ModelAndView mav) {
      memberService.logout(session); //세션 초기화 작업
      mav.setViewName("login"); //이동할 페이지의 이름
      mav.addObject("msg","logout"); //변수 저장 
      return mav; //페이지로 이동
  }

	
}
