package com.tjoeun.spring.member.service;

import javax.servlet.http.HttpSession;

import com.tjoeun.spring.member.dto.MemberDTO;

public interface MemberService {
	
	public boolean loginCheck(MemberDTO dto, HttpSession session);
	public void logout(HttpSession session);
}
