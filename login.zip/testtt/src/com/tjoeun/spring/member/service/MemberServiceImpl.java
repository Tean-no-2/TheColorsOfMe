package com.tjoeun.spring.member.service;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.tjoeun.spring.member.dao.MemberDAO;
import com.tjoeun.spring.member.dto.MemberDTO;

@Service
public class MemberServiceImpl implements MemberService {

	@Autowired
	MemberDAO dao;
	
	@Override
	public boolean loginCheck(MemberDTO dto, HttpSession session) {
		
		boolean result = dao.loginCheck(dto);
		
		if(result == true) {
			session.setAttribute("id", dto.getId());
		
		}
		return result;
	}

	@Override
	public void logout(HttpSession session) {

		dao.logout(session);
	}
	
	
}
