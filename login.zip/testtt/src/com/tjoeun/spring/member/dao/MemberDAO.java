package com.tjoeun.spring.member.dao;

import javax.servlet.http.HttpSession;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.tjoeun.spring.member.dto.MemberDTO;

@Repository
public class MemberDAO {

	@Autowired
	SqlSession sqlSession;
	
	public boolean loginCheck(MemberDTO dto) {
		
		System.out.println("==> mybatis로 logincheck() 기능처리");
		String name = sqlSession.selectOne("memberMapper.loginCheck",dto);
		
		return (Integer.parseInt(name)==0)?false:true;
	}
	
	public void logout(HttpSession session) {
		System.out.println("==>로그아웃 기능 처리");
		session.invalidate();
	}
}
