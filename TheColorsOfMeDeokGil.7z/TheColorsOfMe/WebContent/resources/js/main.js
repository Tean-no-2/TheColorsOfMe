/* const selectElement = (Element) => document.querySelector(Element);

console.log('bafsagsdg')
selectElement('.mobile_topBtn').addEventListener('click', ()=>{
    selectElement('header').classList.toggle('active');
});

selectElement('.nav-link-bag').addEventListener('click',() =>{
    selectElement('.nav-link-bag__list').classList.toggle('seelist');
});


const toogleBtn = document.querySelector('.nav-link-bag');
const menu = document.querySelector('.nav-link-bag__list');

toogleBtn.addEventListener('click',()=>{
    menu.classList.toggle('seelist');
}); */


window.onload = function(){  

  function includeHTML() {
     var z, i, elmnt, file, xhttp;
     z = document.getElementsByTagName("*"); 
     for (i = 0; i < z.length; i++) { 
       elmnt = z[i]; 
       file = elmnt.getAttribute("include-html"); 
       if (file) { 
         xhttp = new XMLHttpRequest(); 
         xhttp.onreadystatechange = function() { 
           if (this.readyState == 4 && this.status == 200) { elmnt.innerHTML = this.responseText; 
            elmnt.removeAttribute("include-html"); 
            includeHTML();
            } 
          } 
          xhttp.open("GET", file, true); 
          xhttp.send(); return; 
        } 
      } 
    }


const toggleBtn = document.querySelector("#mobile_topBtn");
const toggleMenu = document.querySelector("#hide");
const toggleTopBarPhone = document.querySelector
(".topBarPhone");
const toggleTopBarListPhone = document.querySelector(".topBarListPhone");

  toggleBtn.addEventListener('click', ()=>{
  toggleBtn.classList.toggle('active');
  toggleMenu.classList.toggle('active');
  toggleTopBarPhone.classList.toggle('active');
  toggleTopBarListPhone.classList.toggle('active');
}); 

  const toggleBtn2 = document.querySelector("#mobile_topBtn2");
  const toggleMenu2 = document.querySelector("#hide2");
  const toggleTopBarPhone2 = document.querySelector
  (".topBarPhone");
  const toggleTopBarListPhone2 = document.querySelector(".topBarListPhone");

  toggleBtn2.addEventListener('click', ()=>{
    toggleBtn2.classList.toggle('active');
    toggleMenu2.classList.toggle('active');
    toggleTopBarPhone2.classList.toggle('active');
    toggleTopBarListPhone2.classList.toggle('active');
  });

const tooglenav = document.querySelector('.searchBtn');
const topList = document.querySelectorAll('.meun-item');
const searchform = document.querySelector('.search-form');

tooglenav.addEventListener('click',()=>{
  topList.classList.toggle('hide-item');
  searchform.classList.toggle('can-see');
});


/* 
   // 찾아볼것
  function changeAni(){
    var hide = document.getElementById('#hide');
    if (hide.style.animationName == "ani") {
        hide.style.animationName = "ani2";      
    } else {
        hide.style.animationName = "ani";
    }
  }
 */

}


