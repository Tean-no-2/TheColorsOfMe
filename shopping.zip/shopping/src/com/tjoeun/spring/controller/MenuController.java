package com.tjoeun.spring.controller;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.ModelAndView;

import com.tjoeun.spring.service.ListService;

@Controller
public class MenuController {
	
	@Autowired
	private ListService listService;
	
	@GetMapping("/top1_proc")
	public ModelAndView top1(ModelAndView mav) {
		mav.setViewName("/top1");
		mav.addObject("list",listService.getList());
		return mav;
	}

	@GetMapping("/{product_id}")
	public ModelAndView detail(@PathVariable("product_id") int product_id,ModelAndView mav) {
		mav.setViewName("/product_detail");
		mav.addObject("detail",listService.detailProduct(product_id));
		
		return mav;
	}
	
	@PostMapping("/cart")
	public String cart() {
		
		return "cart";
	}
}
