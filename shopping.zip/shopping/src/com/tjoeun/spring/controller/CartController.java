package com.tjoeun.spring.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.tjoeun.spring.dto.CartDTO;
import com.tjoeun.spring.service.CartService;

@Controller
public class CartController {

	@Autowired
	CartService cartService;
		
	@RequestMapping("/insert")
	public String insert(@ModelAttribute CartDTO dto, HttpSession session) {
		
		String id = (String)session.getAttribute("id");
		if(id ==null) {
			return "redirect:/login";
		}
		dto.setId(id);
		cartService.insert(dto);
		return "redirect:/list";
	}
	
	@RequestMapping("/list")
	public ModelAndView list(HttpSession session,ModelAndView mav) {
		Map<String,Object> map = new HashMap<>();
		
		String id = (String)session.getAttribute("id");
		
		if(id != null) {
			List<CartDTO> list = cartService.listCart(id);
			int sumMoney =cartService.sumMoney(id);
			int fee = sumMoney >= 30000 ? 0:2500;
			//배달료 계산
			
			map.put("sumMoney",sumMoney);
			map.put("fee",fee); // 배달료
			map.put("sum",sumMoney+fee);
			map.put("list",list);
			map.put("count",list.size()); //레코드 갯수
			
		mav.setViewName("/cart");
		mav.addObject("map",map);
		
		return mav;
		}else {
			return new ModelAndView("/login","",null);
		}
		
	}
	
	
	
}
