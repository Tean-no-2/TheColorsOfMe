package com.tjoeun.spring.controller;

import java.util.logging.Logger;

import javax.annotation.Resource;
import javax.servlet.http.HttpSession;

import org.mybatis.logging.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.tjoeun.spring.dto.MemberDTO;
import com.tjoeun.spring.service.UserService;

@Controller
public class UserController {

	private static final org.mybatis.logging.Logger logger = LoggerFactory.getLogger(UserController.class);
	
	@Autowired
	private UserService userService;
	
	@Resource(name="loginUserBean")
	@Lazy
	private MemberDTO loginUserBean;
	
	
	@GetMapping("/login")
	public String login() {
		
		return "login";
	}
	
	@RequestMapping("/login_proc")
	public ModelAndView login_proc(MemberDTO dto, HttpSession) {
		
		
		return "login";
	}
	
	
	@GetMapping("/join")
	public String join(@ModelAttribute("userDTO") MemberDTO userDTO) {
		
		
		
		return "join";
	}
	@PostMapping("/join_proc")
	public String join_proc(MemberDTO userDTO,BindingResult result) {
		if(result.hasErrors()) {
			return "join";
		}
		userService.insertUserInfo(userDTO);
		
		return "login";
	}
	
	}
	

