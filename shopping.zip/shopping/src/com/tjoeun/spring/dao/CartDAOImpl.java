package com.tjoeun.spring.dao;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.tjoeun.spring.dto.CartDTO;

@Repository
public class CartDAOImpl implements CartDAO {

	@Autowired
  private SqlSessionTemplate sqlSessionTemplate;
	
	@Override
	public List<CartDTO> cartMoney() {
		return null;
	}

	@Override
	public void insert(CartDTO dto) {
		sqlSessionTemplate.insert("cart.insert",dto);
	}

	@Override
	public List<CartDTO> listCart(String id) {

		
		return sqlSessionTemplate.selectList("cart.listCart",id);
	}

	@Override
	public void delete(int cart_id) {
		sqlSessionTemplate.delete("cart.delete",cart_id);
	}

	@Override
	public void deleteAll(String id) {
		sqlSessionTemplate.delete("cart.deleteAll",id);
	}

	@Override
	public void update(int cart_id) {
		
	}

	@Override
	public int sumMoney(String id) {
		return sqlSessionTemplate.selectOne("cart.sumMoney",id);
	}

	@Override
	public int countCart(String id, int product_id) {

		return 0;
	}

	@Override
	public void updateCart(CartDTO dto) {
		
	}

	@Override
	public void modifyCart(CartDTO dto) {
		sqlSessionTemplate.update("cart.modify",dto);
	}
	
	
	
}
