package com.tjoeun.spring.dao;

import java.util.List;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.tjoeun.spring.dto.ListDTO;
@Repository
public class ListDAO {
	
	@Autowired
  private SqlSessionTemplate sqlSessionTemplate;
	
	public List<ListDTO> getList() {
		return sqlSessionTemplate.selectList("list.getList");
	}
	
	public ListDTO detailProduct(int product_id) {
		return sqlSessionTemplate.selectOne("list.detail_product",product_id);
	}
}
