package com.tjoeun.spring.service;

import java.util.List;

import com.tjoeun.spring.dto.CartDTO;

public interface CartService {
	List<CartDTO> cartMoney();
  void insert(CartDTO dto);
  List<CartDTO> listCart(String id);
  void delete(int cart_id);
  void deleteAll(String id);
  void update(int cart_id);
  int sumMoney(String id);
  int countCart(String id, int product_id);
  void updateCart(CartDTO dto);
  void modifyCart(CartDTO dto);
		
}
