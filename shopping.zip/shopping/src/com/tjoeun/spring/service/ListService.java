package com.tjoeun.spring.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.tjoeun.spring.dao.ListDAO;
import com.tjoeun.spring.dto.ListDTO;

@Service
public class ListService {

		@Autowired
		private ListDAO listDAO;
		
		public List<ListDTO> getList() {
			return listDAO.getList();
		}
		
		public ListDTO detailProduct(int product_id) {
			return listDAO.detailProduct(product_id);
		}
}
