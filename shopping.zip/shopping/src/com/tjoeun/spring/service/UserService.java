package com.tjoeun.spring.service;

import javax.annotation.Resource;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Service;

import com.tjoeun.spring.dao.MemberDAO;
import com.tjoeun.spring.dto.MemberDTO;

@Service
public class UserService {
  
  @Autowired
  private MemberDAO memberDAO;
  
  @Resource(name="loginUserBean")
  @Lazy
	private MemberDTO loginUserBean;
  
 
	public String loginCheck(MemberDTO dto,HttpSession session) {
		String name = memberDAO.loginCheck(dto);
		
		if(name!=null) {
			session.setAttribute("id", dto.getId());
			session.setAttribute("name", name);
		}
		
		return name;
	}

	public void logout(HttpSession session) {
		session.invalidate();
	}
  
public void insertUserInfo(MemberDTO userDTO) {
	memberDAO.insertUserInfo(userDTO);
}
}
