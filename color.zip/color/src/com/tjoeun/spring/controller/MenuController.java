package com.tjoeun.spring.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.tjoeun.spring.service.ProductService;

@Controller
@RequestMapping("/menu")
public class MenuController {

	@Autowired
	ProductService productService;
	
	@RequestMapping("/list_do")
	public ModelAndView item1(ModelAndView mav) {
		mav.setViewName("menu/product_list");
		mav.addObject("list",productService.listProduct());	
		
		return mav;
	}
	
	@RequestMapping("/detail/{product_id}")
	public ModelAndView detail(@PathVariable("product_id") int product_id,ModelAndView mav) {
		
		mav.setViewName("menu/detail");
		mav.addObject("dto",productService.detailProduct(product_id));
		
		return mav;
	}
}
