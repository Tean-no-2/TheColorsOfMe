package com.tjoeun.spring.dao;

import java.util.List;

import com.tjoeun.spring.beans.ProductDTO;

public interface ProductDAO {
	
  List<ProductDTO> listProduct();
  ProductDTO detailProduct(int product_id);
  void updateProduct(ProductDTO dto);
  void deleteProduct(int product_id);
  void insertProduct(ProductDTO dto);
	
}
