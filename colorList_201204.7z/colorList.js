/*  text shadow

let text = document.getElementById('text');
let shadow = '';
for (let i = 0; i < 500; i++) {
  shadow += (shadow ? ',' : '') + i * 1 + 'px ' + i * 1 + 'px 0 rgb(80,80,80)';
}
text.style.textShadow = shadow;
 */