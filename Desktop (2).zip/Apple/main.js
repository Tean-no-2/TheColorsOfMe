/* const selectElement = (Element) => document.querySelector(Element);

console.log('bafsagsdg')
selectElement('.mobile_topBtn').addEventListener('click', ()=>{
    selectElement('header').classList.toggle('active');
});

selectElement('.nav-link-bag').addEventListener('click',() =>{
    selectElement('.nav-link-bag__list').classList.toggle('seelist');
});


const toogleBtn = document.querySelector('.nav-link-bag');
const menu = document.querySelector('.nav-link-bag__list');

toogleBtn.addEventListener('click',()=>{
    menu.classList.toggle('seelist');
}); */

window.onload = function(){  
  
const toggleBtn = document.querySelector("#mobile_topBtn");
const toggleMenu = document.querySelector("#hide");

toggleBtn.addEventListener('click', ()=>{
  toggleBtn.classList.toggle('active');
  toggleMenu.classList.toggle('active');
});

  const toggleBtn2 = document.querySelector("#mobile_topBtn2");
  const toggleMenu2 = document.querySelector("#hide2");
  
  toggleBtn2.addEventListener('click', ()=>{
    toggleBtn2.classList.toggle('active');
    toggleMenu2.classList.toggle('active');
  });
}

