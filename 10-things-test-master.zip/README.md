# 10-things-test
나를 알아보는 10가지 질문 테스트
- - -
HTML5 + CSS3 + Vanilla JS로 만든 이미지 테스트 페이지입니다.  
[개발일지 보기](https://dev-dain.tistory.com/22?category=816329)  

![실행예시](https://img1.daumcdn.net/thumb/R1280x0/?scode=mtistory2&fname=https%3A%2F%2Fk.kakaocdn.net%2Fdn%2FEwF2m%2FbtqDGIAgKyB%2FGK4kXuHrFzJL2Q9p4GKIYk%2Fimg.gif)

페이지 개발자 : [김다인](https://dev-dain.tistory.com)  
그림 작가 : [껴리](https://instagram.com/gyeoly27)  
- - -
## 수정 사용 시 주의 사항
- 이 저장소의 에셋은 반드시 *fork해서 가져가주세요.* 
- 수정 시 README.md 파일에 출처(이 repo 주소와 원 개발자-Dain Kim-의 이름)를 적어주세요.
- 페이지의 결과 부분에 출처(이 repo 주소와 원 개발자-Dain Kim-의 이름)를 적어주세요.
- star는 제게 힘이 됩니다. ^^
