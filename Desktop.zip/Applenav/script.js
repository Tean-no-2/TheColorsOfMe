const selectElement = (Element) => document.querySelector(Element);

console.log('bafsagsdg')
selectElement('.mobile-menu').addEventListener('click', ()=>{
    selectElement('header').classList.toggle('active');
});

selectElement('.nav-link-bag').addEventListener('click',() =>{
    selectElement('.nav-link-bag__list').classList.toggle('seelist');
});


const toogleBtn = document.querySelector('.nav-link-bag');
const menu = document.querySelector('.nav-link-bag__list');

toogleBtn.addEventListener('click',()=>{
    menu.classList.toggle('seelist');
});